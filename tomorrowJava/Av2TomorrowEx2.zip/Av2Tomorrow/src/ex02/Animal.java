package ex02;

public class Animal {
    public String name;          
    protected int age;           

    public void makeSound() {
        System.out.println("Generic animal sound");
    }
}
