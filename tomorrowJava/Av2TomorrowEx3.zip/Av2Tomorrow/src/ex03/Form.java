package ex03;

public abstract class Form {
    public abstract double calculateArea();
}

