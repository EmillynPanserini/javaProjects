package atvClass3;

public class Employee {

    public double calculateSalary() {
        return 0.0;  
    }
}
